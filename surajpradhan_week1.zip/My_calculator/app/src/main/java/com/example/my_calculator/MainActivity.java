package com.example.my_calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText num1,num2;
    TextView txt_answer;
    Button add_btn;
    Button sub_btn;
    Button mul_btn;
    Button div_btn;
    int n1,n2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        num1 = (EditText)findViewById(R.id.num1);
        num2 = (EditText)findViewById(R.id.num2);
        add_btn = (Button)findViewById(R.id.addButton);
        sub_btn = (Button)findViewById(R.id.subButton);
        mul_btn = (Button)findViewById(R.id.mulButton);
        div_btn = (Button)findViewById(R.id.divButton);
        txt_answer = (TextView) findViewById(R.id.answer);



        add_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double  n1 = Double.parseDouble(num1.getText().toString());
                double  n2 = Double.parseDouble(num2.getText().toString());
                double sum = n1 + n2;
                txt_answer.setText("The sum of two numbers is: "+ Double.toString(sum));
            }
        });


        sub_btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    double  n1 = Double.parseDouble(num1.getText().toString());
                    double  n2 = Double.parseDouble(num2.getText().toString());
                    double Minus = n1 - n2;
                    txt_answer.setText("The minus of two numbers is: "+ Double.toString(Minus));
                }
        });

                mul_btn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        double n1 = Double.parseDouble(num1.getText().toString());
                        double n2 = Double.parseDouble(num2.getText().toString());
                        double Multiply = n1 * n2;
                        txt_answer.setText("The multiplication of two numbers is: " + Double.toString(Multiply));
                    }
                });

                div_btn.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            double  n1 = Double.parseDouble(num1.getText().toString());
                            double  n2 = Double.parseDouble(num2.getText().toString());
                            double Division = n1 / n2;
                            txt_answer.setText("The division of two numbers is: "+ Double.toString(Division));
                        }
                });

        };





    }
